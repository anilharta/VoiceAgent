from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores.pgvector import PGVector
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.document_loaders import TextLoader
from config import Config 

import os

embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
texts = TextLoader('data/made-up-story.txt').load()
documents = CharacterTextSplitter(chunk_size=500, chunk_overlap=20).split_documents(texts)

config = Config()

class EmbeddingService:
    def get_embedding(self, query):

        return embeddings.embed_query(query)
    
    DB_CONNECTION_STRING = PGVector.connection_string_from_db_params(
            dbname=config.DB_NAME,
            user=config.DB_USER,
            password=config.DB_PASSWORD,
            host=config.DB_HOST,
            port=config.DB_PORT
        )
    
    db = PGVector.from_documents(
    embedding=embeddings,
    documents=documents,
    collection_name="test",
    connection_string=DB_CONNECTION_STRING,
)
