#from langchain_community.llms import HuggingFaceHub
from langchain_community.document_loaders import DirectoryLoader
from langchain.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings

from config import Config
config = Config()
import os
os.environ["OPENAI_API_KEY"] = "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"
from dotenv import load_dotenv
load_dotenv()

# secret_key = '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'
# #config.SECRET_KEY
# print(f'Secret Key:::::::::::::::::::::::::::::::::::-{secret_key}')

loader = DirectoryLoader(config.FOLDER_PATH)
documents = loader.load()
print(f'Total Documents in direcory are:- {len(documents)}')

text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=20)
texts = text_splitter.split_documents(documents)

# print(len(texts))
# print(texts[0])
embeddings = OpenAIEmbeddings()

vector = embeddings.embed_query('Testing the embedding model')

print(f'Total Vector Length:-{len(vector)}')