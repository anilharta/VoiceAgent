import os
import re
import uuid
import time
import json
import fitz  # PyMuPDF
import psycopg2
from google.cloud import speech, language_v1
import google.generativeai as genai
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_postgres import PGVector
from langchain.chains import RetrievalQA
from langchain_community.llms import HuggingFaceHub
from langchain_community.document_loaders import (
    UnstructuredPDFLoader, UnstructuredWordDocumentLoader, UnstructuredExcelLoader, TextLoader
)
from langchain_core.documents import Document
from docx import Document as DocxDocument
from config import Config
from models.document_model import DocumentModel

class DocumentService:
    def __init__(self):
        self.config = Config()
        self.speech_client = speech.SpeechClient()
        self.language_client = language_v1.LanguageServiceClient()
        self.gemini_api_key = self.config.GEMINI_API_KEY
        self.model = genai.GenerativeModel(self.config.MODEL)
        self.folder_path = self.config.FOLDER_PATH
        self.embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
        self.vector_store = PGVector(
            embeddings=self.embeddings,
            collection_name='huggingface',
            connection=self.config.PGVECTOR_CONN_STRING,
            use_jsonb=True,
        )
        with open(self.config.PROMPTS_PATH, 'r') as f:
            self.prompts = f.read().strip()
        self.load_and_store_documents()

    def load_documents(self):
        """Load documents from the directory based on file type."""
        docs = []
        for filename in os.listdir(self.folder_path):
            filepath = os.path.join(self.folder_path, filename)
            if filename.endswith(".pdf"):
                loader = UnstructuredPDFLoader(filepath)
            elif filename.endswith(".docx"):
                loader = UnstructuredWordDocumentLoader(filepath)
            elif filename.endswith(".xlsx"):
                loader = UnstructuredExcelLoader(filepath)
            elif filename.endswith(".txt"):
                loader = TextLoader(filepath)
            else:
                continue  # Skip unsupported files
            
            # Load the document as a single chunk
            loaded_docs = loader.load()
            for doc in loaded_docs:
                doc.page_content = " ".join(doc.page_content.split())  # Ensure no chunking
            docs.extend(loaded_docs)
        return docs

    def load_and_store_documents(self):
        """Load documents and store their embeddings in the vector database."""
        docs = self.load_documents()
        print(f"Total Documents in directory: {len(docs)}")
        if not docs:
            return
        
        for doc in docs:
            doc.metadata["id"] = doc.metadata.get("id", str(uuid.uuid4()))

        existing_ids = self.get_existing_document_ids()
        existing_contents = self.get_existing_document_contents()

        new_docs = []
        for doc in docs:
            if doc.metadata["id"] in existing_ids:
                raise ValueError(f"Document with ID {doc.metadata['id']} already exists in the vector store.")
            if doc.page_content in existing_contents:
                raise ValueError("A document with the same content already exists in the vector store.")
            new_docs.append(doc)

        if new_docs:
            self.vector_store.add_documents(new_docs, ids=[doc.metadata["id"] for doc in new_docs])
            print(f"{len(new_docs)} new documents successfully added to vector store.")
        else:
            print("No new documents to add. All embeddings are already stored.")

    def get_existing_document_ids(self):
        """Retrieve all existing document IDs from the vector database."""
        conn = psycopg2.connect(self.config.PGVECTOR_CONN_STRING)
        cursor = conn.cursor()
        cursor.execute("SELECT collection_id FROM langchain_pg_embedding")
        existing_ids = set(row[0] for row in cursor.fetchall())
        cursor.close()
        conn.close()
        return existing_ids

    def get_existing_document_contents(self):
        """Retrieve all existing document contents from the vector database."""
        conn = psycopg2.connect(self.config.PGVECTOR_CONN_STRING)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM langchain_pg_embedding")  # Assuming 'content' column stores document text
        existing_contents = set(row[0] for row in cursor.fetchall())
        cursor.close()
        conn.close()
        return existing_contents

    def retrieve_information(self, query, k=3):
        similar_docs = self.vector_store.similarity_search_with_score(query, k=k)
        relevant_texts = [doc.page_content for doc, _ in similar_docs]
        if relevant_texts:
            return "\n".join(relevant_texts)
        return "No relevant information found."
    
    def refine_answer(self, question, context):
        input_text = f"Context: {context}\nQuestion: {question}\nAnswer: {self.prompts}"
        response = self.model.generate_content(input_text)
        # Preprocess the response to remove special characters
        return self.preprocess_response(response.text)
    
    def run_qa(self, query):
        context = self.retrieve_information(query)
        if context == "No relevant information found.":
            return context
        return self.refine_answer(query, context)
    
    def fetch_information(self, query):
        return self.run_qa(query)
    
    def preprocess_response(self, text):
        """Clean response to remove special characters and ensure natural readability."""
        text = re.sub(r'[^a-zA-Z0-9\s.,!?]', '', text)  # Allow basic punctuation
        text = re.sub(r'\s+', ' ', text).strip()        # Normalize whitespace
        return text
    
    def convert_voice_to_text(self, audio_data):
        audio = speech.RecognitionAudio(content=audio_data)
        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
            sample_rate_hertz=16000,
            language_code="en-US",
        )
        response = self.speech_client.recognize(config=config, audio=audio)
        return response.results[0].alternatives[0].transcript