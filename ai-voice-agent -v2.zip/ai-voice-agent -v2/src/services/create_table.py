import psycopg2
from config import Config  # Import the Config class from config.py

def create_table():
    config = Config()
    print(f"dbname----------{config.DB_NAME}")
    print(f"user----------{config.DB_USER}")
    print(f"password----------{config.DB_PASSWORD}")
    print(f"host----------{config.DB_HOST}")
    print(f"port----------{config.DB_PORT}")
    
    connection = psycopg2.connect(
        dbname=config.DB_NAME,        
        user=config.DB_USER,
        password=config.DB_PASSWORD,
        host=config.DB_HOST,
        port=config.DB_PORT
    )
    cursor = connection.cursor()
    
    create_extension_query = "CREATE EXTENSION IF NOT EXISTS vector;"
    create_table_query = '''
    CREATE TABLE document_embeddings (
        document_id UUID PRIMARY KEY,
        embeddings vector(768)  -- Adjust the dimension based on your embedding size
    );
    '''
    
    try:
        cursor.execute(create_extension_query)
        cursor.execute(create_table_query)
        connection.commit()
        print("Table 'document_embeddings' created successfully.")
    except Exception as e:
        print(f"Error creating table: {e}")
        connection.rollback()
    finally:
        cursor.close()
        connection.close()

if __name__ == "__main__":
    create_table()
