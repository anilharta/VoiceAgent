from langchain_huggingface import HuggingFaceEmbeddings
from langchain_postgres import PGVector
from langchain.chains import RetrievalQA
from langchain_community.llms import HuggingFaceHub
from langchain_community.document_loaders import (
    UnstructuredPDFLoader, UnstructuredWordDocumentLoader, UnstructuredExcelLoader
)
from langchain_core.documents import Document
from langchain.vectorstores import FAISS

import os
import uuid
from config import Config
import time

config = Config()

# Load documents based on file type
def load_documents(directory):
    docs = []
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        if filename.endswith(".pdf"):
            loader = UnstructuredPDFLoader(filepath)
        elif filename.endswith(".docx"):
            loader = UnstructuredWordDocumentLoader(filepath)
        elif filename.endswith(".xlsx"):
            loader = UnstructuredExcelLoader(filepath)
        else:
            continue  # Skip unsupported files
        docs.extend(loader.load())
    return docs

docs = load_documents(config.FOLDER_PATH)
print(f"Total Documents in directory: {len(docs)}")
print(f"Sample document content: {docs[0].page_content[:100]}")

# Initialize embeddings
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")

# PGVector connection details
CONNECTION_STRING = config.PGVECTOR_CONN_STRING
COLLECTION_NAME = 'huggingface'
print(f'Connected to DB: {CONNECTION_STRING}')

def generate_embeddings(docs, vector_store, collection_name):
    """
    Generate embeddings for documents and add them to the vector store.
    """
    # Ensure documents have unique IDs
    for doc in docs:
        if "id" not in doc.metadata or not doc.metadata["id"]:
            doc.metadata["id"] = str(uuid.uuid4())

    # Check if embeddings already exist in the vector store
    import psycopg2

    # Create a database connection
    conn = psycopg2.connect(config.PGVECTOR_CONN_STRING)
    cursor = conn.cursor()

    # Retrieve all existing document IDs
    cursor.execute(f"SELECT collection_id FROM langchain_pg_embedding")
    existing_ids = set(row[0] for row in cursor.fetchall())

    # Close the connection
    cursor.close()
    conn.close()

    # Filter out documents whose IDs already exist
    new_docs = [doc for doc in docs if doc.metadata["id"] not in existing_ids]

    if new_docs:
        # Add only new documents to the vector store
        vector_store.add_documents(new_docs, ids=[doc.metadata["id"] for doc in new_docs])
        print(f"New documents successfully added to vector store: {collection_name}")
    else:
        print("No new documents to add. All embeddings are already stored.")

def retrieve_embeddings(query, vector_store, retries=3, k=2):
    """
    Retrieve embeddings using similarity search.
    """
    for _ in range(retries):  # Retry up to 'retries' times
        try:
            similar_docs = vector_store.similarity_search_with_score(query, k=k)
            return similar_docs
        except Exception as e:
            print(f"Retrying due to error: {e}")
            time.sleep(5)  # Wait for 5 seconds before retrying
    return []

# Create vector store
vector_store = PGVector(
    embeddings=embeddings,
    collection_name=COLLECTION_NAME,
    connection=CONNECTION_STRING,
    use_jsonb=True,
)

# Generate embeddings
generate_embeddings(docs, vector_store, COLLECTION_NAME)

# Perform similarity search
query = "Who is Sumit Jaitly?"
similar_docs = retrieve_embeddings(query, vector_store)

for doc, score in similar_docs:
    print(f"Score: {score}, Content: {doc.page_content[:200]}")

# Initialize LLM
huggingface_api_token = config.HUGGINGFACE_API_TOKEN
llm = HuggingFaceHub(
    repo_id="google/flan-t5-large",
    model_kwargs={"temperature": 0.0},
    huggingfacehub_api_token=huggingface_api_token
)
# Create retriever
retriever = vector_store.as_retriever(search_kwargs={"k": 3})

qa = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    chain_type='stuff'
)

# Run QA system
answer = qa.run(query)
print("Here is the answer to your question::::::::::::::::::::::::::::::")
print(f"Final Answer========== {answer}")

query = "my query"
docs = vector_store.similarity_search(query)
print(f"result------------------{docs}")
