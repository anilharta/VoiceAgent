from google.cloud import speech
from google.cloud import language_v1
import os
import re
import fitz  # PyMuPDF
import google.generativeai as genai
from models.document_model import DocumentModel
import json
import sys
# from langchain.vectorstores import FAISS
# from langchain.embeddings import OpenAIEmbeddings
# from langchain.embeddings import HuggingFaceEmbeddings
from langchain.document_loaders import TextLoader
from config import Config  # Import the Config class from config.py
#from langgraph import LangGraph  # Import the LangGraph class
from docx import Document  # Add this import for handling .docx files

class DocumentService:
    def __init__(self):
        self.config = Config()  # Initialize the Config class without config_path
        self.speech_client = speech.SpeechClient()
        self.language_client = language_v1.LanguageServiceClient()
        self.gemini_api_key = self.config.GEMINI_API_KEY
        model_name = self.config.MODEL
        self.model = genai.GenerativeModel(model_name)
        self.folder_path = self.config.FOLDER_PATH
        #self.langgraph = LangGraph()
        
        # Load prompt from configuration file
        #with open('D:/1. Development/AI/AgenticAI/ai-voice-agent/config/prompts.json') as f:
        # with open(self.config.PROMPTS_PATH) as f:
        #     self.prompts = json.load(f)

        # Load prompt from a text file
        with open(self.config.PROMPTS_PATH, 'r') as f:
            self.prompts = f.read().strip()

    # def extract_text_from_pdf(self, pdf_path):
    #     text = ""
    #     try:
    #         with fitz.open(pdf_path) as doc:
    #             for page in doc:
    #                 text += page.get_text()
    #         if not text:
    #             raise ValueError("No text found in the PDF document.")
    #     except Exception as e:
    #         print(f"Error extracting text from PDF: {e}")
    #     return text
        
    # def evaluate_with_gemini(self, question, context):
    #     # Preprocess the input text
    #     input_text = question.lower()
    #     input_text = f"Context: {context}\nQuestion: {question}\nAnswer: {self.prompts['gemini_prompt']}"
    #     response = self.model.generate_content(input_text)
    #     return response.text

    def evaluate_with_gemini(self, question, context):
        # Preprocess the input text
        input_text = question.lower()
        input_text = f"Context: {context}\nQuestion: {question}\nAnswer: {self.prompts}"
        response = self.model.generate_content(input_text)
        return response.text
    
    def fetch_information(self, query):
        folder_path = self.folder_path        
        all_text = ""
        relevant_texts = []
        
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            print(f"Processing file: {file_path}")
            document_model = DocumentModel(file_path)
            if document_model:
                result = document_model.extract_information(query)
                if result:
                    all_text += result + "\n"
                    if "Query not found in document." not in result:
                        relevant_texts.append(result)
   
        if relevant_texts:
            combined_text = "\n".join(relevant_texts)
            return self.evaluate_with_gemini(query, self.preprocess_responce(combined_text.strip()))
        return "No relevant information found in the documents."
    
    def preprocess_responce(self, text):
        # Remove special characters
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text  
        
    # def fetch_information(self, query):
    #     folder_path = self.folder_path        
    #     all_text = ""
    #     relevant_texts = []
        
    #     for filename in os.listdir(folder_path):
    #         if filename.endswith(('.pdf', '.docx', '.txt')):
    #             file_path = os.path.join(folder_path, filename).replace('\\', '/')
    #             print(f"Processing file: {file_path}")
    #             document_model = DocumentModel(file_path)
    #             print(f"Extracting text from: {document_model.document_type}")                
    #             extracted_text = document_model.extract_information(query)
    #             all_text += extracted_text + "\n"
    #             if "Query not found in document." not in extracted_text:
    #                 relevant_texts.append(extracted_text)
                
    #     if relevant_texts:
    #         combined_text = "\n".join(relevant_texts)
    #         return self.evaluate_with_gemini(query, combined_text.strip())
    #     return "No relevant information found in the documents"

    def convert_voice_to_text(self, audio_data):
        audio = speech.RecognitionAudio(content=audio_data)
        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
            sample_rate_hertz=16000,
            language_code="en-US",
        )
        response = self.speech_client.recognize(config=config, audio=audio)
        return response.results[0].alternatives[0].transcript
