import os
import fitz  # PyMuPDF
import docx
import pandas as pd
import PyPDF2
import re

class UnifiedDocumentModel:
    def __init__(self, folder_path):
        self.folder_path = folder_path

    def detect_document_type(self, file_path):
        if file_path.endswith('.pdf'):
            return 'pdf'
        elif file_path.endswith('.docx'):
            return 'word'
        elif file_path.endswith('.xlsx') or file_path.endswith('.xls'):
            return 'excel'
        else:
            return None

    def extract_information(self, query):
        for filename in os.listdir(self.folder_path):
            file_path = os.path.join(self.folder_path, filename)
            document_type = self.detect_document_type(file_path)
            if document_type:
                if document_type == 'pdf':
                    result = self.extract_from_pdf(file_path, query)
                elif document_type == 'word':
                    result = self.extract_from_word(file_path, query)
                elif document_type == 'excel':
                    result = self.extract_from_excel(file_path, query)
                if result:
                    print(f"Document name: {filename}")
                    return self.format_response(query, result)
        return "No relevant information found in the documents."

    def format_response(self, query, result):
        if re.match(r'^[A-Za-z\s]+$', query):
            return f"{query} is {result}"
        else:
            return f"{result} is {query}"

    def extract_from_pdf(self, file_path, query):
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ''
            for page in reader.pages:
                text += page.extract_text()
            return self.search_query_in_text(text, query)

    def extract_from_word(self, file_path, query):
        document = docx.Document(file_path)
        text = '\n'.join([para.text for para in document.paragraphs])
        return self.search_query_in_text(text, query)

    def extract_from_excel(self, file_path, query):
        df = pd.read_excel(file_path)
        text = '\n'.join(df.astype(str).values.flatten())
        return self.search_query_in_text(text, query)

    def search_query_in_text(self, text, query):
        if not isinstance(text, str):
            return "Invalid document text"
        normalized_text = re.sub(r'\s+', ' ', text).strip().lower()
        normalized_query = re.sub(r'\s+', ' ', query).strip().lower()
        if normalized_query in normalized_text:
            sentences = re.split(r'(?<=[.!?]) +', text)
            for sentence in sentences:
                if normalized_query in re.sub(r'\s+', ' ', sentence).strip().lower():
                    return self.extract_relevant_info(sentence, query)
        return None

    def extract_relevant_info(self, sentence, query):
        words = query.split()
        for word in words:
            if word.lower() in sentence.lower():
                return sentence.strip()
        return sentence.strip()

# Example usage
if __name__ == "__main__":
    folder_path = "D:/1. Development/AI/AgenticAI/ai-voice-agent/src/documents"
    query = "Sanjay"
    print(f"Searching for query: '{query}' in documents in folder: {folder_path}")
    document_model = UnifiedDocumentModel(folder_path)
    print(f"document model=====<><><><><>=======: {document_model}")
    result = document_model.extract_information(query)
    print(f"Result: {result}")