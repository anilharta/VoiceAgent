from src.models.pdf_document_model import PDFDocumentModel
from src.models.word_document_model import WordDocumentModel
from src.models.excel_document_model import ExcelDocumentModel

class DocumentModel:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.document_type = self.detect_document_type()
        self.document_model = self.get_document_model()
  
    def detect_document_type(self):
        if self.folder_path.endswith('.pdf'):
            return 'pdf'
        elif self.folder_path.endswith('.docx'):
            return 'word'
        elif self.folder_path.endswith('.xlsx') or self.file_path.endswith('.xls'):
            return 'excel'
        else:
            raise ValueError(f"Unsupported document type for file: {self.file_path}")

    def get_document_model(self):
        if self.document_type == 'pdf':
            return PDFDocumentModel(self.folder_path)
        elif self.document_type == 'word':
            return WordDocumentModel(self.folder_path)
        elif self.document_type == 'excel':
            return ExcelDocumentModel(self.folder_path)
        else:
            raise ValueError("Unsupported document type")

    def extract_information(self, query):
        return self.get_document_model().extract_information(query)