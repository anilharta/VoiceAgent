import re
import nltk
from textblob import TextBlob
from nltk.corpus import wordnet
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Download necessary NLTK data files
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')

class BaseDocumentModel:
    def __init__(self, file_path):
        self.file_path = file_path

    def get_wordnet_pos(self, word):
        """Map POS tag to first character lemmatize() accepts"""
        tag = nltk.pos_tag([word])[0][1][0].upper()
        tag_dict = {"J": wordnet.ADJ,
                    "N": wordnet.NOUN,
                    "V": wordnet.VERB,
                    "R": wordnet.ADV}
        return tag_dict.get(tag, wordnet.NOUN)

    def lemmatize_text(self, text):
        lemmatizer = WordNetLemmatizer()
        tokens = word_tokenize(text)
        lemmatized_tokens = [lemmatizer.lemmatize(token, self.get_wordnet_pos(token)) for token in tokens]
        return ' '.join(lemmatized_tokens)

    def extract_information(self, query):
        # Autocorrect the query
        corrected_query = str(TextBlob(query).correct())
        text = self.load_document()
        return self.search_query_in_text(text, corrected_query)

    def search_query_in_text(self, text, query):
        if not isinstance(text, str):
            return "Invalid document text"
        
        # Normalize text and query
        normalized_text = re.sub(r'\s+', ' ', text).strip().lower()
        normalized_query = re.sub(r'\s+', ' ', query).strip().lower()
        
        # Split text into sentences
        sentences = re.split(r'(?<=[.!?]) +', text)
        
        # Use TF-IDF Vectorizer to find the best matching sentence
        vectorizer = TfidfVectorizer().fit_transform([normalized_query] + sentences)
        vectors = vectorizer.toarray()
        cosine_similarities = cosine_similarity(vectors[0:1], vectors[1:]).flatten()
        best_match_index = cosine_similarities.argmax()
        best_match = sentences[best_match_index]
        
        return self.extract_relevant_info(best_match, query)

    def extract_relevant_info(self, sentence, query):
        # Use TextBlob to extract relevant information
        sentence_blob = TextBlob(sentence)
        for word in query.split():
            if word.lower() in sentence_blob.words.lower():
                return sentence.strip()        
        return sentence.strip()