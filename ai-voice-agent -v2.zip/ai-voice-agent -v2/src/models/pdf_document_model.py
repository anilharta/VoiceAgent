import fitz  # PyMuPDF
import PyPDF2
from models.base_document_model import BaseDocumentModel

class PDFDocumentModel(BaseDocumentModel):
        
    def __init__(self, file_path):
        self.file_path = file_path

    def extract_information(self, query):
        pdf_path = self.file_path
        print(f"PDF Path--------: {pdf_path}")
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ''
            for page in reader.pages:
               # if query.lower() in page.extract_text().lower():
                 text += page.extract_text()
            return self.search_query_in_text(text, query)