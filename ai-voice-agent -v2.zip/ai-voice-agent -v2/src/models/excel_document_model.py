import pandas as pd
from models.base_document_model import BaseDocumentModel

class ExcelDocumentModel(BaseDocumentModel):
    def __init__(self, file_path):
        self.file_path = file_path

    def extract_information(self, query):
        print(f"Excel Path--------: {self.file_path}")
        df = pd.read_excel(self.file_path)
        text = '\n'.join(df.astype(str).values.flatten())
        return self.search_query_in_text(text, query)