import docx
from models.base_document_model import BaseDocumentModel

class WordDocumentModel(BaseDocumentModel):
    
    def __init__(self, file_path):
        self.file_path = file_path

    def extract_information(self, query):
        print(f"Word Path--------: {self.file_path}")
        document = docx.Document(self.file_path)
        text = '\n'.join([para.text for para in document.paragraphs])
        return self.search_query_in_text(text, query)
       