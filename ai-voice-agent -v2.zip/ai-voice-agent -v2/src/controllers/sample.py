import os
import fitz  # PyMuPDF
import docx
import pandas as pd
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def search_pdf(file_path, query):
    try:
        document = fitz.open(file_path)
        for page_num in range(len(document)):
            page = document.load_page(page_num)
            text = page.get_text()
            if query.lower() in text.lower():
                return text
    except Exception as e:
        logging.error(f"Error reading PDF file {file_path}: {e}")
    return None

def search_docx(file_path, query):
    try:
        document = docx.Document(file_path)
        for para in document.paragraphs:
            if query.lower() in para.text.lower():
                return para.text
    except Exception as e:
        logging.error(f"Error reading DOCX file {file_path}: {e}")
    return None

def search_excel(file_path, query):
    try:
        df = pd.read_excel(file_path)
        for column in df.columns:
            for cell in df[column]:
                if query.lower() in str(cell).lower():
                    return str(cell)
    except Exception as e:
        logging.error(f"Error reading Excel file {file_path}: {e}")
    return None

def search_documents(folder_path, query):
    results = {}
    for root, _, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(root, file)
            if file.lower().endswith('.pdf'):
                result = search_pdf(file_path, query)
            elif file.lower().endswith('.docx'):
                result = search_docx(file_path, query)
            elif file.lower().endswith('.xlsx') or file.lower().endswith('.xls'):
                result = search_excel(file_path, query)
            else:
                continue

            if result:
                results[file_path] = result

    return results

def format_results(results):
    formatted_results = []
    for file_path, content in results.items():
        formatted_results.append(f"File: {file_path}\nContent: {content}\n")
    return "\n".join(formatted_results)

def chatbot_response(folder_path, query):
    results = search_documents(folder_path, query)
    if results:
        return format_results(results)
    else:
        return "No relevant information found in the documents."

# Example usage
if __name__ == "__main__":
    folder_path = "D:/1. Development/AI/AgenticAI/ai-voice-agent/src/documents"
    query = "Jasvir Singh"
    response = chatbot_response(folder_path, query)
    print(response)