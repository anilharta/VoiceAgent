from services.document_service import DocumentService

class QueryController:
    def __init__(self, document_service: DocumentService):
        self.document_service = document_service

    def process_query(self, query):
        # Process the user query and fetch responses from various resources
        response = self.document_service.fetch_information(query)
        return response

    def handle_voice_input(self, voice_data):
        # Process voice input and convert it to text query
        text_query = self.document_service.convert_voice_to_text(voice_data)
        return self.process_query(text_query)

    def stop_conversation(self):
        # Logic to stop the conversation
        pass