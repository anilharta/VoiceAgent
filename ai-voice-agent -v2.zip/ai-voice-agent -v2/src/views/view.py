from flask import render_template

class View:
    def render_index(self):
        return render_template('index.html')