document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const sendButton = document.getElementById('send-button');
    const voiceInputButton = document.getElementById('voice-input-button');
    const stopButton = document.getElementById('stop-button');
    const userInput = document.getElementById('user-input');
    const chatBody = document.getElementById('chat-body');
    const statusIndicator = document.getElementById('status-indicator');
    const statusText = document.getElementById('status-text');
    const clearChatButton = document.getElementById('clear-chat');
    const emojiButton = document.getElementById('emoji-button');
    const attachButton = document.getElementById('attach-button');

    // Bot information
    const botName = "Genius Desk";
    const botAvatar = '<i class="fas fa-robot"></i>';
    
    // Add welcome message
    addBotMessage("Hello! I'm your AI voice assistant. How can I help you today?");
    
    // Attach event listeners
    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    clearChatButton.addEventListener('click', clearChat);
    
    // Voice recognition setup
    let recognition;
    if ('webkitSpeechRecognition' in window) {
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = function() {
            console.log('Voice recognition started.');
            voiceInputButton.classList.add('active');
            showStatus('Listening...', 'fa-circle-notch fa-spin');
        };

        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            userInput.value = transcript;
            hideStatus();
            
            // Short delay for better UX
            setTimeout(() => {
                sendMessage();
            }, 300);
        };

        recognition.onerror = function(event) {
            console.error('Voice recognition error', event);
            showStatus('Voice recognition error. Try again.', 'fa-exclamation-circle');
            setTimeout(hideStatus, 3000);
            voiceInputButton.classList.remove('active');
        };

        recognition.onend = function() {
            console.log('Voice recognition ended.');
            voiceInputButton.classList.remove('active');
            hideStatus();
        };
    } else {
        console.warn('Web Speech API is not supported in this browser.');
        voiceInputButton.style.display = 'none';
        stopButton.style.display = 'none';
    }

    // Event listeners for voice buttons
    voiceInputButton.addEventListener('click', function() {
        if (recognition) {
            try {
                recognition.start();
            } catch (error) {
                console.error('Recognition already started:', error);
            }
        }
    });

    stopButton.addEventListener('click', function() {
        if (recognition) {
            recognition.stop();
            voiceInputButton.classList.remove('active');
            hideStatus();
        }
        window.speechSynthesis.cancel();
    });

    // Optional buttons (could be implemented in future)
    emojiButton.addEventListener('click', function() {
        showStatus('Emoji picker not implemented in this demo', 'fa-info-circle');
        setTimeout(hideStatus, 2000);
    });
    
    attachButton.addEventListener('click', function() {
        showStatus('File attachment not implemented in this demo', 'fa-info-circle');
        setTimeout(hideStatus, 2000);
    });

    // Core functions
    function sendMessage() {
        const query = userInput.value.trim();
        if (query) {
            addUserMessage(query);
            sendQuery(query);
            userInput.value = '';
        }
    }

    function addUserMessage(text) {
        const messageContainer = document.createElement('div');
        messageContainer.classList.add('message-container', 'user', 'fade-in-right');
        
        const message = document.createElement('div');
        message.classList.add('message', 'user');
        message.textContent = text;
        
        const timestamp = document.createElement('div');
        timestamp.classList.add('time-stamp');
        timestamp.textContent = getCurrentTime();
        
        messageContainer.appendChild(message);
        messageContainer.appendChild(timestamp);
        
        chatBody.appendChild(messageContainer);
        scrollToBottom();
    }

    function addBotMessage(text) {
        const messageContainer = document.createElement('div');
        messageContainer.classList.add('message-container', 'bot', 'fade-in-left');
        
        // Bot info at the top of the message
        const messageInfo = document.createElement('div');
        messageInfo.classList.add('message-info');
        
        const botAvatarElement = document.createElement('div');
        botAvatarElement.classList.add('bot-avatar');
        botAvatarElement.innerHTML = botAvatar;
        
        const botNameElement = document.createElement('span');
        botNameElement.textContent = botName;
        
        messageInfo.appendChild(botAvatarElement);
        messageInfo.appendChild(botNameElement);
        
        // Message content
        const message = document.createElement('div');
        message.classList.add('message', 'bot');
        message.textContent = text;
        
        // Timestamp
        const timestamp = document.createElement('div');
        timestamp.classList.add('time-stamp');
        timestamp.textContent = getCurrentTime();
        
        messageContainer.appendChild(messageInfo);
        messageContainer.appendChild(message);
        messageContainer.appendChild(timestamp);
        
        chatBody.appendChild(messageContainer);
        scrollToBottom();
    }

    function addTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.classList.add('typing-indicator', 'fade-in');
        indicator.id = 'typing-indicator';
        
        // Add bot avatar to typing indicator
        const botAvatarElement = document.createElement('div');
        botAvatarElement.classList.add('bot-avatar');
        botAvatarElement.innerHTML = botAvatar;
        indicator.appendChild(botAvatarElement);
        
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('div');
            dot.classList.add('typing-dot');
            indicator.appendChild(dot);
        }
        
        chatBody.appendChild(indicator);
        scrollToBottom();
        return indicator;
    }

    function removeTypingIndicator() {
        const indicator = document.getElementById('typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }

    function sendQuery(query) {
        const typingIndicator = addTypingIndicator();
        
        // Show thinking status
        showStatus('Processing your request...', 'fa-brain');
        
        fetch('/query', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query: query })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            removeTypingIndicator();
            hideStatus();
            
            if (data.error) {
                addBotMessage(`Error: ${data.error}`);
            } else {
                addBotMessage(data.response);
                speakResponse(data.response);
            }
        })
        .catch(error => {
            removeTypingIndicator();
            hideStatus();
            console.error('Error:', error);
            addBotMessage(`I'm sorry, there was an error processing your request. Please try again.`);
        });
    }

    function speakResponse(text) {
        if ('speechSynthesis' in window) {
            // Show speaking status
            showStatus('Speaking...', 'fa-volume-up');
            
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = 1.0;
            utterance.pitch = 1.0;
            
            utterance.onend = function() {
                hideStatus();
            };
            
            window.speechSynthesis.speak(utterance);
        }
    }

    function showStatus(text, iconClass) {
        statusText.textContent = text;
        
        // Update icon if provided
        if (iconClass) {
            const iconElement = statusIndicator.querySelector('i');
            if (iconElement) {
                iconElement.className = `fas ${iconClass}`;
            }
        }
        
        statusIndicator.classList.add('visible');
    }

    function hideStatus() {
        statusIndicator.classList.remove('visible');
    }

    function scrollToBottom() {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function getCurrentTime() {
        const now = new Date();
        let hours = now.getHours();
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        return `${hours}:${minutes} ${ampm}`;
    }
    
    function clearChat() {
        // Keep only the first welcome message
        while (chatBody.childNodes.length > 1) {
            chatBody.removeChild(chatBody.lastChild);
        }
        
        // Show confirmation
        showStatus('Chat cleared', 'fa-check-circle');
        setTimeout(hideStatus, 1500);
    }

    // Focus input field on load
    userInput.focus();
});