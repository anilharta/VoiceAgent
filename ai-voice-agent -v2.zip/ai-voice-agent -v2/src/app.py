# filepath: /D:/1. Development/AI/AgenticAI/ai-voice-agent/src/app.py
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from flask import Flask, request, jsonify, render_template
from controllers.query_controller import QueryController
from views.view import View
from config import Config
from services.document_service import DocumentService

app = Flask(__name__, template_folder='views/templates', static_folder='views/static')
app.config.from_object(Config)

# Verify the GOOGLE_APPLICATION_CREDENTIALS environment variable
print("GOOGLE_APPLICATION_CREDENTIALS:", os.getenv('GOOGLE_APPLICATION_CREDENTIALS'))

# Initialize services
document_service = DocumentService()

# Initialize controllers
query_controller = QueryController(document_service=document_service)
#view = View()

# Define routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/query', methods=['POST'])
def query():
    query_text = request.json.get('query')
    response = query_controller.process_query(query_text)
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=app.config['DEBUG'])