def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def list_files_in_directory(directory_path):
    import os
    return [f for f in os.listdir(directory_path) if os.path.isfile(os.path.join(directory_path, f))]

def extract_text_from_pdf(pdf_path):
    from PyPDF2 import PdfReader
    text = ""
    with open(pdf_path, 'rb') as file:
        reader = PdfReader(file)
        for page in reader.pages:
            text += page.extract_text() + "\n"
    return text

def extract_text_from_word(docx_path):
    from docx import Document
    doc = Document(docx_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

def extract_text_from_excel(xlsx_path):
    import pandas as pd
    df = pd.read_excel(xlsx_path)
    return df.to_string()

def process_files_in_directory(directory_path):
    files_data = {}
    for file_name in list_files_in_directory(directory_path):
        file_path = os.path.join(directory_path, file_name)
        if file_name.endswith('.pdf'):
            files_data[file_name] = extract_text_from_pdf(file_path)
        elif file_name.endswith('.docx'):
            files_data[file_name] = extract_text_from_word(file_path)
        elif file_name.endswith('.xlsx'):
            files_data[file_name] = extract_text_from_excel(file_path)
    return files_data