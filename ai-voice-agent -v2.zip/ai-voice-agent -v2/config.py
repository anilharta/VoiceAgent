import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY')
    DEBUG = os.getenv('DEBUG', 'False') == 'True'
    ALLOWED_EXTENSIONS = {'pdf', 'docx', 'xlsx'}
    UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER')
    DATABASE_URI = os.getenv('DATABASE_URI')
    LANGGRAPH_API_KEY = os.getenv('LANGGRAPH_API_KEY')
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
    FOLDER_PATH = os.getenv('FOLDER_PATH')
    MODEL = os.getenv('MODEL')
    PROMPTS_PATH = os.getenv('PROMPTS')
    GOOGLE_APPLICATION_CREDENTIALS = os.getenv('GOOGLE_APPLICATION_CREDENTIALS')
    WEBSITES = os.getenv('WEBSITES').split(',')
    PGVECTOR_CONN_STRING = os.getenv('PGVECTOR_CONN_STRING')
    DB_NAME = os.getenv('DB_NAME')
    DB_USER = os.getenv('DB_USER')
    DB_PASSWORD = os.getenv('DB_PASSWORD')
    DB_HOST = os.getenv('DB_HOST')
    DB_PORT = os.getenv('DB_PORT')
    EMBEDDING_MODEL = os.getenv('EMBEDDING_MODEL') 
    PGVECTOR_VECTOR_SIZE = os.getenv('PGVECTOR_VECTOR_SIZE')
    HUGGINGFACE_API_TOKEN = os.getenv('HUGGINGFACE_API_TOKEN')
    SECRET_KEY = os.getenv('SECRET_KEY')
