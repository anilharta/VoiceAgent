# AI Voice Agent

## Overview
The AI Voice Agent is a powerful application designed to process user queries verbally and fetch accurate responses from various resources, including PDFs, Word documents, Excel files, websites, and databases. It utilizes LangGraph and Retrieval-Augmented Generation (RAG) technologies to deliver efficient and accurate information retrieval.

## Features
- Voice input for user queries
- Support for multiple document types (PDF, Word, Excel)
- Efficient extraction of relevant information from documents
- User-friendly web interface with interactive elements

## Technology Stack
- **Backend**: Python, Flask
- **AI Technologies**: LangGraph, Google Gemini (or other LLMs)
- **Frontend**: HTML, CSS, JavaScript

## Project Structure
```
ai-voice-agent
├── src
│   ├── controllers
│   │   └── query_controller.py
│   ├── models
│   │   └── document_model.py
│   ├── views
│   │   ├── templates
│   │   │   └── index.html
│   │   ├── static
│   │   │   ├── css
│   │   │   │   └── styles.css
│   │   │   └── js
│   │   │       └── scripts.js
│   │   └── view.py
│   ├── services
│   │   └── document_service.py
│   ├── utils
│   │   └── file_utils.py
│   └── app.py
├── requirements.txt
├── README.md
└── config.py
```

## Setup Instructions
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd ai-voice-agent
   ```
3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Configure the application settings in `config.py`.
5. Run the application:
   ```
   python src/app.py
   ```

## Usage
- Open your web browser and navigate to `http://localhost:5000`.
- Use the voice input icon to speak your query or type it in the message box.
- Click the send icon to submit your query or the stop button to end the conversation.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.